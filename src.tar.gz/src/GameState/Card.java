
public class Card {
	
	enum Types { SOLDIER, HORSE, CANNON};
	
	Types type;
	
	Territory territory;
	
}
