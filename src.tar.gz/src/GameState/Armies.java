
public class Armies {
	int amount;
	Armies(int amount){	
		this.amount = amount;
	}


	
}
