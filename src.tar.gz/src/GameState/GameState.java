
public class GameState {

	static int numOfPlayers;
	static Map map;
}
