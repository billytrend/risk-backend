import java.util.ArrayList;


public class Player {

	// armies they have on board -- maybe for Ai?

	// armies to place on board
	int armiesToPlace;
	
	// think about removing that? ??? 
	ArrayList<Territory> territories = new ArrayList<Territory>();

	ArrayList<Card> cards = new ArrayList<Card>();
	
}
