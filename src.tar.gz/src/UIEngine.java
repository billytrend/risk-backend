
public class UIEngine {
	// should check whether your attacker/defender and
	// get he num of dice accordingly
	static int getNumOfDice(boolean attacker){
			return 0;
		}

	static int getTerritory(){
			return 0;
		}

	static int getNumOfArmies(){
			return 0;
		}
	static int getNumOfPlayers(){
			return 0;
	}
}
